package com.nirmal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.comments.pertsol.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.comments.pertsol.dto.CommentResponse;
import com.comments.pertsol.model.Comments;
import com.comments.pertsol.service.CommentService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/v2")
public class CommentsController {
	
	@Autowired
	private CommentService service;
	
	@GetMapping("/comments")
	public ResponseEntity<Object> getAllComments() {
		CommentsController.log.info("Received request for fetch All Comments"
				);
        
        return service.fetchAll();     
   
    }
	

	public String fetchAllComments() {
		
		return service.fetchAll().toString();
		
	}
	
	@GetMapping("/comments/search")
	public ResponseEntity<Object> fetchByUsername(@RequestParam(required = false) String username, @RequestParam(required = false) String timestamp) {
		
		CommentsController.log.info("Received request for fetch Comments By username | Uername :: {} ",
				username
				);
		return service.findByUsernameOrTimestamp(username, timestamp);
		
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



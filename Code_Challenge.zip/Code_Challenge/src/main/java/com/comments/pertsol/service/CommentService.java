package com.comments.pertsol.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.comments.pertsol.dto.CommentResponse;
import com.comments.pertsol.dto.FailResponse;
import com.comments.pertsol.model.Comments;
import com.comments.pertsol.repository.CommentsRepository;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class CommentService {

	@Autowired
	private CommentsRepository repository;

	public ResponseEntity<Object> fetchAll() {

		CommentService.log.info("Received request for fetch All Comments");
		try {
			List<Comments> list = repository.findAll();
			List<String> listOfComment = new ArrayList<String>();
			if (!list.isEmpty()) {

				CommentService.log.info("List of comments | Comments :: {} ", listOfComment.toString());

				for (Comments comment : list) {
					listOfComment.add(comment.getComment());
				}
				CommentResponse response = CommentResponse.builder().comments(listOfComment).build();
				return new ResponseEntity<Object>(response, HttpStatus.OK);
			} else {
				CommentService.log.info("Data not found in database | Comments :: {} ", "");
				return new ResponseEntity<Object>(new CommentResponse(), HttpStatus.OK);
			}
		} catch (Exception e) {
			CommentService.log.error("Getting an Error while fetching the Comments  | Error :: {} ", e.getMessage());
			
			FailResponse failedResponse = FailResponse.builder()
					.msg(e.getMessage()).build();
			return new ResponseEntity<Object>(failedResponse, HttpStatus.BAD_REQUEST);
		}
	}

	public ResponseEntity<Object> findByUsernameOrTimestamp(String username, String timestamp) {
		
		CommentService.log.info("Received request for fetch Comments by username | Username :: {}",
				username);
		try {
			if(!StringUtils.isEmpty(timestamp)) {
				
				return findByDate(timestamp);
			}
			if(StringUtils.isEmpty(username)) {
				CommentService.log.info("Request username is Null");
				return new ResponseEntity<Object>(new FailResponse().builder().msg("Please insert username").build(), HttpStatus.BAD_REQUEST);
			}
			Comments comments = repository.findByUsername(username);
			if(comments != null) {
			CommentService.log.info("fetch by Username  | Data :: {}",
					comments.toString());
			List<String> list = new ArrayList<String>();
			list.add(comments.getComment());
			return new ResponseEntity<Object>(new CommentResponse().builder().comments(list).build(), HttpStatus.OK);
			}
			else {
				CommentService.log.info("Data not found in database  | Data :: {}");
				return new ResponseEntity<Object>(new FailResponse().builder().msg("Data not available for given user").build(), HttpStatus.OK);
			}
			
		}catch (Exception e) {
			
			CommentService.log.error("Getting an Error while fetching the Comments by Username  | username :: {} | Error :: {} ",
					username, e.getMessage());
			
			FailResponse failedResponse = FailResponse.builder()
					.msg(e.getMessage()).build();

			return new ResponseEntity<Object>(failedResponse, HttpStatus.BAD_REQUEST);
			
		}
		
		
	}

	public ResponseEntity<Object> findByDate(String timestamp) {
		
		CommentService.log.info("Received request for fetch Comments by timestamp | Timestamp :: {}",
				timestamp);

		try {
			if(StringUtils.isEmpty(timestamp)) {
				CommentService.log.info("Request username is Null");
				return new ResponseEntity<Object>(new FailResponse().builder().msg("Please insert username").build(), HttpStatus.BAD_REQUEST);
			}
			Timestamp time = Timestamp.valueOf(timestamp);
			
			
			List<Comments> comments = repository.findByCommentedTimestamp(time);
			if(comments != null) {
			CommentService.log.info("Comments fetch by timestamp | Data :: {}",
					comments.toString());
			List<String> commentList = new ArrayList<String>();
			for(Comments comment : comments) {
				commentList.add(comment.getComment());
			}
			
			return new ResponseEntity<Object>(new CommentResponse().builder().comments(commentList).build(), HttpStatus.OK);
			}
			else {
				CommentService.log.info("Data not found in database  | Data :: {}");
				return new ResponseEntity<Object>(new FailResponse().builder().msg("Data not available for given timestamp").build(), HttpStatus.OK);
			}
			
			
		}
		catch (Exception e) {
			CommentService.log.error("Getting an Error while fetching the Comments by Timestamp  | timestamp :: {} | Error :: {} ",
					timestamp, e.getMessage());
			
			FailResponse failedResponse = FailResponse.builder()
					.msg(e.getMessage()).build();

			return new ResponseEntity<Object>(failedResponse, HttpStatus.BAD_REQUEST);
		}
		
	}

}

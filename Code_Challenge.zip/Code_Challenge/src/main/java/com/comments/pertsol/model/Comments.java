package com.comments.pertsol.model;



import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity(name = "comments")
public class Comments {
	
	@Id
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "By")
	private String username;
	
	@Column(name = "Text")
	private String comment;
	
	@Column(name = "dataofcomment")
	private Timestamp commentedTimestamp;

}

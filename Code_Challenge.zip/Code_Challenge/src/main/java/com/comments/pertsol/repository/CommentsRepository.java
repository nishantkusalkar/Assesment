package com.comments.pertsol.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.comments.pertsol.model.Comments;

@Repository
public interface CommentsRepository extends JpaRepository<Comments, Integer> {
	
	public Comments findByUsername(String username);
	
	public List<Comments> findByCommentedTimestamp(Timestamp timestamp);

}

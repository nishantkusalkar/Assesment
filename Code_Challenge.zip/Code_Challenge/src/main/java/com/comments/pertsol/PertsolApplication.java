package com.comments.pertsol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PertsolApplication {

	public static void main(String[] args) {
		SpringApplication.run(PertsolApplication.class, args);
	}

}
